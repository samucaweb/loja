<div class="container">
    <div class="container_sobre_min">
        <div class="body_sobre_min">
            <div class="imglogo">
                <img src="<?php echo BASE_URL;?>assets/images/logo3.png" border="0"/>
            </div>
            <div class="sobre_min">
                <p>Ala  tudo bem com voce aque vai fica coisa sobre min nao esqueça de sempre olha o codigo com calma.
                ola tudo bem com voce aque vai fica coisa sobre min nao esqueça de sempre olha o codigo com calma.
                ola tudo bem com voce aque vai fica coisa sobre min nao esqueça de sempre olha o codigo com calma.
                ola tudo bem com voce aque vai fica coisa sobre min nao esqueça de sempre olha o codigo com calma.
                ola tudo bem com voce aque vai fica coisa sobre min nao esqueça de sempre olha o codigo com calma.
                ola tudo bem com voce aque vai fica coisa sobre min nao esqueça de sempre olha o codigo com calma.
                ola tudo bem com voce aque vai fica coisa sobre min nao esqueça de sempre olha o codigo com calma.
                ola tudo bem com voce aque vai fica coisa sobre min nao esqueça de sempre olha o codigo com calma.
                ola tudo bem com voce aque vai fica coisa sobre min nao esqueça de sempre olha o codigo com calma.ola tudo bem com voce aque vai fica coisa sobre min nao esqueça de sempre olha o codigo com calma.
                ola tudo bem com voce aque vai fica coisa sobre min nao esqueça de sempre olha o codigo com calma.</p>

            <p> ola tudo bem com voce aque vai fica coisa sobre min nao esqueça de sempre olha o codigo com calma.
                ola tudo bem com voce aque vai fica coisa sobre min nao esqueça de sempre olha o codigo com calma.ola tudo bem com voce aque vai fica coisa sobre min nao esqueça de sempre olha o codigo com calma.
                ola tudo bem com voce aque vai fica coisa sobre min nao esqueça de sempre olha o codigo com calma.

                ola tudo bem com voce aque vai fica coisa sobre min nao esqueça de sempre olha o codigo com calma.
                ola tudo bem com voce aque vai fica coisa sobre min nao esqueça de sempre olha o codigo com calma.
                ola tudo bem com voce aque vai fica coisa sobre min nao esqueça de sempre olha o codigo com calma.ola tudo bem com voce aque vai fica coisa sobre min nao esqueça de sempre olha o codigo com calma.
                ola tudo bem com voce aque vai fica coisa sobre min nao esqueça de sempre olha o codigo com calma.
                </p>
                
            </div>
        </div>
    </div>
</div>