<?php
class pages extends Model {


}